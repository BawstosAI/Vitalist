import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, ComposedChart, ReferenceLine } from 'recharts';
import { Card, SectionHeader } from './Shared';
import { ORGANS, generateTrajectories } from '../constants';

const PopulationTrajectories: React.FC = () => {
  // Generate data for all organs
  const data = useMemo(() => {
    const liver = generateTrajectories('Liver');
    const cardio = generateTrajectories('Cardio-Metabolic');
    const immune = generateTrajectories('Immune');
    
    // Merge for chart
    return liver.map((pt, i) => ({
      ageBin: pt.ageBin,
      Liver: pt.meanGap,
      Cardio: cardio[i].meanGap,
      Immune: immune[i].meanGap
    }));
  }, []);

  return (
    <div className="h-full flex flex-col animate-fadeIn">
      <SectionHeader title="Population Trajectories" subtitle="Cross-sectional trends of biological aging across the lifespan." />
      
      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 lg:col-span-9">
          <Card title="Mean Age Gap by Age Group (Pseudo-Longitudinal)">
            <div className="h-[450px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={data}
                  margin={{ top: 20, right: 30, left: 20, bottom: 10 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="ageBin" label={{ value: 'Age Group (Decades)', position: 'insideBottom', offset: -5, fontSize: 12 }} />
                  <YAxis label={{ value: 'Mean Age Gap (Years)', angle: -90, position: 'insideLeft' }} />
                  <Tooltip 
                    contentStyle={{border: '1px solid #E5E7EB', borderRadius: '4px', fontSize: '12px'}} 
                    formatter={(value: number) => [value.toFixed(2) + ' yrs', 'Mean Gap']}
                  />
                  <Legend verticalAlign="top" height={36} />
                  <ReferenceLine y={0} stroke="#000" strokeWidth={1} />
                  
                  <Line type="monotone" dataKey="Liver" stroke="#F59E0B" strokeWidth={3} dot={{r: 4}} activeDot={{r: 6}} />
                  <Line type="monotone" dataKey="Cardio" stroke="#EF4444" strokeWidth={3} dot={{r: 4}} activeDot={{r: 6}} />
                  <Line type="monotone" dataKey="Immune" stroke="#10B981" strokeWidth={3} dot={{r: 4}} activeDot={{r: 6}} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="p-4 bg-gray-50 text-sm text-gray-600 border-t border-gray-100 mt-2">
              <p className="mb-1"><strong>Observation:</strong> While the Immune system (Green) tends to remain resilient or stable in the population average, the Cardio-Metabolic system (Red) shows a distinct trend of accelerated aging in older cohorts.</p>
            </div>
          </Card>
        </div>

        <div className="col-span-12 lg:col-span-3 space-y-6">
           <Card title="Cohort Stats">
             <div className="space-y-4">
               <div>
                 <div className="text-xs text-gray-500 uppercase">Total Samples</div>
                 <div className="text-2xl font-bold text-gray-800">45,201</div>
               </div>
               <div>
                 <div className="text-xs text-gray-500 uppercase">Age Range</div>
                 <div className="text-xl font-semibold text-gray-800">18 - 80</div>
               </div>
               <hr />
               <div>
                  <div className="text-xs text-gray-500 uppercase mb-2">Trajectory Type</div>
                  <span className="inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded border border-yellow-200">Pseudo-Longitudinal</span>
                  <p className="text-xs text-gray-400 mt-2 italic">
                    Data represents discrete age bins, not longitudinal follow-up of the same individuals.
                  </p>
               </div>
             </div>
           </Card>

           <Card title="Clustering Insight">
             <div className="text-sm text-gray-600">
               <p className="mb-2">K-Means analysis on Age Gap vectors identifies 3 primary aging phenotypes:</p>
               <ul className="list-disc pl-4 space-y-1">
                 <li><span className="font-semibold text-red-700">Metabolic-Drivers:</span> High Cardio/Liver gaps.</li>
                 <li><span className="font-semibold text-green-700">Resilient:</span> Negative gaps across all systems.</li>
                 <li><span className="font-semibold text-blue-700">Renal-Specific:</span> Isolated Kidney aging.</li>
               </ul>
             </div>
           </Card>
        </div>
      </div>
    </div>
  );
};

export default PopulationTrajectories;