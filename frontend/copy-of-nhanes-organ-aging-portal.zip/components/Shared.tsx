import React, { ReactNode } from 'react';

// --- Layout Wrappers ---

export const Card: React.FC<{ children: ReactNode; className?: string; title?: string; subtitle?: string }> = ({ 
  children, className = "", title, subtitle 
}) => (
  <div className={`bg-white border border-gray-300 rounded-sm shadow-sm flex flex-col ${className}`}>
    {(title || subtitle) && (
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50/50">
        {title && <h3 className="text-sm font-semibold text-gray-800">{title}</h3>}
        {subtitle && <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>}
      </div>
    )}
    <div className="p-4 flex-1">
      {children}
    </div>
  </div>
);

export const Badge: React.FC<{ children: ReactNode; color?: 'blue' | 'green' | 'red' | 'gray' }> = ({ children, color = 'gray' }) => {
  const styles = {
    blue: 'bg-blue-100 text-blue-800',
    green: 'bg-green-100 text-green-800',
    red: 'bg-red-100 text-red-800',
    gray: 'bg-gray-100 text-gray-800',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${styles[color]}`}>
      {children}
    </span>
  );
};

export const SectionHeader: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="mb-6 border-b border-gray-200 pb-4">
    <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{title}</h1>
    {subtitle && <p className="text-slate-500 mt-1 text-sm">{subtitle}</p>}
  </div>
);
