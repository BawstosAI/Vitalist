import React, { ReactNode } from 'react';
import { Activity, Database, GitBranch, TrendingUp, Users } from 'lucide-react';
import { Card } from './Shared';

const Overview: React.FC = () => {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Summary */}
      <div className="bg-white border border-gray-300 p-6 rounded-sm shadow-sm">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-slate-800">Organ-specific Biological Aging from NHANES</h2>
            <p className="text-slate-600 mt-2 max-w-3xl text-sm leading-relaxed">
              This project constructs <strong>organ-specific aging clocks</strong> using cross-sectional NHANES data. 
              By modeling the non-linear relationship between biomarkers and chronological age, we derive 
              <strong> Biological Age</strong> and <strong>Age Gap</strong> metrics for six distinct organ systems.
              These metrics allow us to infer pseudo-trajectories and identify the "next organ to fail" at an individual level.
            </p>
          </div>
          <div className="flex flex-col items-end">
             <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-medium border border-blue-200">
               Dataset: NHANES (2000-2018)
             </span>
             <span className="text-xs text-gray-400 mt-1">N ≈ 45,000 Participants</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        
        {/* Pipeline Diagram */}
        <div className="col-span-12 lg:col-span-8">
          <Card title="Methodology Pipeline" className="h-full">
            <div className="flex flex-col md:flex-row items-stretch justify-between gap-4 py-8 px-2 h-full">
              
              <PipelineStep 
                icon={<Database size={20} />}
                title="1. Data Ingestion"
                desc="Load Raw XPT/CSV. Merge demographics, labs, and exam data."
                color="bg-slate-50"
              />
              <Arrow />
              <PipelineStep 
                icon={<GitBranch size={20} />}
                title="2. Preprocessing"
                desc="Filter ages (18-80). Impute missings. Define organ feature panels."
                color="bg-slate-50"
              />
              <Arrow />
              <PipelineStep 
                icon={<Activity size={20} />}
                title="3. Modeling"
                desc="Train XGBoost regressors per organ. Predict Chronological Age."
                color="bg-blue-50 border-blue-200"
              />
              <Arrow />
              <PipelineStep 
                icon={<TrendingUp size={20} />}
                title="4. Analysis"
                desc="Calculate AgeGaps. Cluster trajectories. Project failures."
                color="bg-indigo-50 border-indigo-200"
              />
              
            </div>
          </Card>
        </div>

        {/* Key Metrics */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <Card title="Project Statistics">
            <div className="grid grid-cols-2 gap-4">
              <StatBox label="Organ Systems" value="6" />
              <StatBox label="Biomarkers" value="48" />
              <StatBox label="Avg MAE (Non-Lin)" value="5.2 yrs" highlight />
              <StatBox label="Avg MAE (Linear)" value="6.8 yrs" />
            </div>
          </Card>
          
          <Card title="Core Concepts" className="flex-1">
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex gap-2">
                <span className="font-bold text-gray-800 min-w-[80px]">Organ Clock:</span>
                <span>ML model predicting age based on organ-specific markers.</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-gray-800 min-w-[80px]">Age Gap:</span>
                <span>Bio Age - Chronological Age. (+ means accelerated aging).</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-gray-800 min-w-[80px]">Pseudo-Longitudinal:</span>
                <span>Inferring trajectories from cross-sectional bins.</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
};

const PipelineStep: React.FC<{ title: string; desc: string; icon: ReactNode; color: string }> = ({ title, desc, icon, color }) => (
  <div className={`flex-1 flex flex-col items-center text-center p-4 rounded-lg border border-gray-200 ${color} transition-all hover:shadow-md`}>
    <div className="mb-3 text-slate-700">{icon}</div>
    <h4 className="font-bold text-slate-800 text-sm mb-1">{title}</h4>
    <p className="text-xs text-slate-500 leading-snug">{desc}</p>
  </div>
);

const Arrow = () => (
  <div className="hidden md:flex items-center text-gray-300">
    <TrendingUp className="rotate-90 md:rotate-0" size={24} />
  </div>
);

const StatBox: React.FC<{ label: string; value: string; highlight?: boolean }> = ({ label, value, highlight }) => (
  <div className="p-3 bg-gray-50 rounded border border-gray-100 text-center">
    <div className={`text-2xl font-bold ${highlight ? 'text-blue-600' : 'text-gray-800'}`}>{value}</div>
    <div className="text-xs text-gray-500 uppercase tracking-wide mt-1">{label}</div>
  </div>
);

export default Overview;