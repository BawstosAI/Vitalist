import React, { useState, useMemo } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, BarChart, Bar, Legend, ReferenceLine } from 'recharts';
import { Card, SectionHeader } from './Shared';
import { ORGANS, generateScatterData, ORGAN_PERFORMANCE } from '../constants';
import { OrganType } from '../types';

const OrganClocks: React.FC = () => {
  const [selectedOrgan, setSelectedOrgan] = useState<OrganType>('Liver');
  const [modelType, setModelType] = useState<'Linear' | 'Non-Linear'>('Non-Linear');

  // Memoize expensive data generation
  const scatterData = useMemo(() => generateScatterData(selectedOrgan, modelType), [selectedOrgan, modelType]);
  const performance = ORGAN_PERFORMANCE.find(p => p.organ === selectedOrgan)!;

  return (
    <div className="h-full flex flex-col animate-fadeIn">
      <SectionHeader 
        title="Organ Clocks Explorer" 
        subtitle="Analyze model performance and linearity across organ systems."
      />

      <div className="grid grid-cols-12 gap-6 flex-1">
        
        {/* Left Column: Charts */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          
          {/* Regression Plot */}
          <Card title={`${selectedOrgan} Clock: Predicted vs Chronological Age (${modelType})`}>
            <div className="h-[400px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    type="number" 
                    dataKey="chronoAge" 
                    name="Chronological Age" 
                    unit=" yrs" 
                    domain={[18, 80]} 
                    label={{ value: 'Chronological Age', position: 'insideBottom', offset: -10, fontSize: 12 }}
                  />
                  <YAxis 
                    type="number" 
                    dataKey="bioAge" 
                    name="Biological Age" 
                    unit=" yrs" 
                    domain={[18, 90]} 
                    label={{ value: 'Predicted Bio Age', angle: -90, position: 'insideLeft', fontSize: 12 }}
                  />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ fontSize: '12px' }} />
                  {/* Identity Line simulation using reference line is tricky in Recharts scatter, conceptually it's x=y */}
                  <ReferenceLine segment={[{ x: 18, y: 18 }, { x: 80, y: 80 }]} stroke="#9CA3AF" strokeWidth={2} strokeDasharray="5 5" />
                  
                  <Scatter name="Individuals" data={scatterData} fill="#2563EB" fillOpacity={0.4}>
                    {scatterData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.bioAge > entry.chronoAge + 5 ? '#B91C1C' : entry.bioAge < entry.chronoAge - 5 ? '#047857' : '#2563EB'} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
              <div className="absolute top-4 left-16 bg-white/90 p-2 text-xs text-gray-600 border border-gray-200 rounded">
                 <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-gray-400"></span> Line of Identity (x=y)</div>
                 <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-red-700"></span> Accelerated Aging</div>
              </div>
            </div>
          </Card>

          {/* Comparison Chart */}
          <Card title="Model Benchmark (All Organs)" className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={ORGAN_PERFORMANCE}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="organ" tick={{fontSize: 11}} />
                <YAxis label={{ value: 'MAE (Years)', angle: -90, position: 'insideLeft', fontSize: 12 }} />
                <Tooltip cursor={{fill: '#F3F4F6'}} />
                <Legend />
                <Bar dataKey="maeLinear" name="Linear Baseline" fill="#9CA3AF" radius={[4, 4, 0, 0]} />
                <Bar dataKey="maeNonLinear" name="XGBoost (Non-Linear)" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Right Column: Controls & Stats */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <Card title="Controls">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Select Organ System</label>
                <select 
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block p-2.5"
                  value={selectedOrgan}
                  onChange={(e) => setSelectedOrgan(e.target.value as OrganType)}
                >
                  {ORGANS.map(org => <option key={org} value={org}>{org}</option>)}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Model Type</label>
                <div className="flex rounded-md shadow-sm" role="group">
                  <button 
                    type="button" 
                    className={`px-4 py-2 text-sm font-medium border rounded-l-lg ${modelType === 'Linear' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}
                    onClick={() => setModelType('Linear')}
                  >
                    Linear
                  </button>
                  <button 
                    type="button" 
                    className={`px-4 py-2 text-sm font-medium border border-l-0 rounded-r-lg ${modelType === 'Non-Linear' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}
                    onClick={() => setModelType('Non-Linear')}
                  >
                    Non-Linear
                  </button>
                </div>
              </div>
            </div>
          </Card>

          <Card title="Current Performance Metrics">
            <div className="grid grid-cols-2 gap-4">
               <div className="p-3 bg-gray-50 border border-gray-200 rounded">
                  <div className="text-xs text-gray-500 mb-1">MAE</div>
                  <div className="text-xl font-mono font-bold text-gray-800">{modelType === 'Linear' ? performance.maeLinear : performance.maeNonLinear} <span className="text-sm font-normal text-gray-500">yrs</span></div>
               </div>
               <div className="p-3 bg-gray-50 border border-gray-200 rounded">
                  <div className="text-xs text-gray-500 mb-1">RMSE</div>
                  <div className="text-xl font-mono font-bold text-gray-800">{modelType === 'Linear' ? performance.rmseLinear : performance.rmseNonLinear} <span className="text-sm font-normal text-gray-500">yrs</span></div>
               </div>
               <div className="p-3 bg-gray-50 border border-gray-200 rounded col-span-2">
                  <div className="text-xs text-gray-500 mb-1">R² (Variance Explained)</div>
                  <div className="text-xl font-mono font-bold text-gray-800">{performance.r2}</div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                    <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: `${performance.r2 * 100}%` }}></div>
                  </div>
               </div>
            </div>
          </Card>

          <div className="bg-blue-50 border border-blue-200 p-4 rounded text-sm text-blue-900">
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Interpretation
            </h4>
            <p className="leading-relaxed opacity-90">
              The non-linear XGBoost model reduces Mean Absolute Error (MAE) by approximately 
              <strong> {(performance.maeLinear - performance.maeNonLinear).toFixed(1)} years</strong> compared to the linear baseline for the {selectedOrgan} clock, 
              suggesting significant non-linear aging dynamics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganClocks;
