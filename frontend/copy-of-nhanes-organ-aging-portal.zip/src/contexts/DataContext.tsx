
import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { OrganMetric, Individual, ScatterPoint, TrajectoryPoint, Biomarker, OrganType } from '../types';
import { 
  ORGAN_PERFORMANCE as MOCK_PERFORMANCE, 
  INDIVIDUALS as MOCK_INDIVIDUALS, 
  generateScatterData, 
  generateTrajectories,
  LIVER_FEATURES, KIDNEY_FEATURES
} from '../constants';

// Define the shape of our total data state
interface AppData {
  loading: boolean;
  metrics: OrganMetric[];
  individuals: Individual[];
  trajectories: Record<string, TrajectoryPoint[]>; // Keyed by OrganType (simplified string key)
  scatterData: Record<string, ScatterPoint[]>;     // Keyed by OrganType + ModelType
  features: Record<string, Biomarker[]>;           // Keyed by OrganType
}

const DataContext = createContext<AppData | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<AppData>({
    loading: true,
    metrics: [],
    individuals: [],
    trajectories: {},
    scatterData: {},
    features: {},
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        // 1. Try to fetch real data from the public/data folder
        // You need to generate these JSON files from your Python pipeline
        const [metricsRes, indsRes, trajRes, featRes] = await Promise.all([
          fetch('/data/metrics.json'),
          fetch('/data/individuals_subset.json'),
          fetch('/data/trajectories.json'),
          fetch('/data/features.json')
        ]);

        if (metricsRes.ok && indsRes.ok && trajRes.ok) {
          const metrics = await metricsRes.json();
          const individuals = await indsRes.json();
          const trajectories = await trajRes.json();
          const features = await featRes.json();

          // For scatter plots, real data might be too large (45k rows).
          // We recommend fetching a subsample (e.g., 2000 points) or generating it on the fly if files are missing.
          // Here we assume a 'scatter_subsample.json' exists, otherwise we mock it.
          let scatterData: Record<string, ScatterPoint[]> = {};
          try {
            const scatterRes = await fetch('/data/scatter_subsample.json');
            if (scatterRes.ok) {
              scatterData = await scatterRes.json();
            } else {
              throw new Error('No scatter file');
            }
          } catch (e) {
            // Fallback: Generate scatter based on real metrics if possible, or fully mock
            console.warn("Using mock scatter generation based on real metrics");
             ['Liver', 'Kidney', 'Cardio-Metabolic', 'Immune', 'Lung', 'Musculoskeletal'].forEach(organ => {
               scatterData[`${organ}-Linear`] = generateScatterData(organ as OrganType, 'Linear');
               scatterData[`${organ}-Non-Linear`] = generateScatterData(organ as OrganType, 'Non-Linear');
             });
          }

          setData({
            loading: false,
            metrics,
            individuals,
            trajectories,
            scatterData,
            features
          });
          return;
        }
        throw new Error("Real data not found");
      } catch (error) {
        console.warn("Real data not detected (or error loading). Falling back to Mock Data.", error);
        
        // --- FALLBACK TO MOCK DATA (constants.ts) ---
        
        // Pre-generate complex mocks
        const mockScatter: Record<string, ScatterPoint[]> = {};
        const mockTraj: Record<string, TrajectoryPoint[]> = {};
        const organs: OrganType[] = ['Liver', 'Kidney', 'Cardio-Metabolic', 'Immune', 'Lung', 'Musculoskeletal'];
        
        organs.forEach(org => {
          mockScatter[`${org}-Linear`] = generateScatterData(org, 'Linear');
          mockScatter[`${org}-Non-Linear`] = generateScatterData(org, 'Non-Linear');
          mockTraj[org] = generateTrajectories(org);
        });

        setData({
          loading: false,
          metrics: MOCK_PERFORMANCE,
          individuals: MOCK_INDIVIDUALS,
          trajectories: mockTraj,
          scatterData: mockScatter,
          features: {
            'Liver': LIVER_FEATURES,
            'Kidney': KIDNEY_FEATURES
          }
        });
      }
    };

    loadData();
  }, []);

  return (
    <DataContext.Provider value={data}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
