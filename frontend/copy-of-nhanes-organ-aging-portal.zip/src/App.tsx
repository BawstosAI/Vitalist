
import React, { useState } from 'react';
import { Activity, User, Users, FileText, LayoutDashboard, Dna } from 'lucide-react';
import Overview from './components/Overview';
import OrganClocks from './components/OrganClocks';
import IndividualExplorer from './components/IndividualExplorer';
import PopulationTrajectories from './components/PopulationTrajectories';
import Explainability from './components/Explainability';
import { DataProvider, useData } from './contexts/DataContext';

type Tab = 'overview' | 'clocks' | 'individual' | 'population' | 'explain';

const DashboardContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const { loading } = useData();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F6F7]">
        <div className="flex flex-col items-center animate-pulse">
           <Dna className="text-blue-600 mb-4 h-10 w-10 animate-spin" />
           <p className="text-slate-500 font-medium">Loading NHANES Dataset...</p>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'overview': return <Overview />;
      case 'clocks': return <OrganClocks />;
      case 'individual': return <IndividualExplorer />;
      case 'population': return <PopulationTrajectories />;
      case 'explain': return <Explainability />;
      default: return <Overview />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F7] text-slate-800 font-sans flex animate-fadeIn">
      
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-full z-10">
        <div className="h-16 flex items-center px-6 border-b border-gray-100">
          <div className="flex items-center gap-2 text-blue-700">
            <Dna size={24} strokeWidth={2.5} />
            <span className="font-bold text-lg tracking-tight">BioAge<span className="text-slate-800">Portal</span></span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <NavItem 
            active={activeTab === 'overview'} 
            onClick={() => setActiveTab('overview')} 
            icon={<LayoutDashboard size={18} />} 
            label="Overview" 
          />
          <div className="pt-4 pb-1 px-3 text-xs font-bold text-gray-400 uppercase tracking-wider">Analytics</div>
          <NavItem 
            active={activeTab === 'clocks'} 
            onClick={() => setActiveTab('clocks')} 
            icon={<Activity size={18} />} 
            label="Organ Clocks" 
          />
          <NavItem 
            active={activeTab === 'individual'} 
            onClick={() => setActiveTab('individual')} 
            icon={<User size={18} />} 
            label="Individual Explorer" 
          />
          <NavItem 
            active={activeTab === 'population'} 
            onClick={() => setActiveTab('population')} 
            icon={<Users size={18} />} 
            label="Population Trajectories" 
          />
          <div className="pt-4 pb-1 px-3 text-xs font-bold text-gray-400 uppercase tracking-wider">Science</div>
          <NavItem 
            active={activeTab === 'explain'} 
            onClick={() => setActiveTab('explain')} 
            icon={<FileText size={18} />} 
            label="Explainability" 
          />
        </nav>

        <div className="p-4 border-t border-gray-100">
          <div className="bg-slate-50 rounded p-3 text-xs text-gray-500">
            <p className="font-semibold text-gray-700 mb-1">Project NHANES-48</p>
            <p>Ver 1.2.0 (Cross-sectional)</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 flex flex-col min-h-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm">
           <div className="text-sm text-gray-500">
             Context: <span className="font-semibold text-gray-700">Scientific Jury Presentation</span>
           </div>
           <div className="flex items-center gap-4">
              <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded text-gray-600">READ-ONLY MODE</span>
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold text-xs">JD</div>
           </div>
        </header>
        
        <div className="flex-1 overflow-auto p-8">
           <div className="max-w-7xl mx-auto h-full">
             {renderContent()}
           </div>
        </div>
      </main>
    </div>
  );
};

const NavItem: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors ${
      active 
        ? 'bg-blue-50 text-blue-700 border border-blue-100' 
        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
    }`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const App: React.FC = () => {
  return (
    <DataProvider>
      <DashboardContent />
    </DataProvider>
  );
}

export default App;
