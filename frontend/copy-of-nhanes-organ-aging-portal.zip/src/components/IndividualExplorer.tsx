
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer, Cell } from 'recharts';
import { Card, SectionHeader, Badge } from './Shared';
import { ORGANS } from '../constants';
import { useData } from '../contexts/DataContext';
import { User, AlertTriangle } from 'lucide-react';

const IndividualExplorer: React.FC = () => {
  const { individuals } = useData();
  const [selectedId, setSelectedId] = useState<string>('');
  
  // Set default selection when data loads
  useEffect(() => {
    if (individuals.length > 0 && !selectedId) {
      setSelectedId(individuals[0].id);
    }
  }, [individuals, selectedId]);

  const currentInd = individuals.find(i => i.id === selectedId) || individuals[0];

  if (!currentInd) return <div>No individual data available.</div>;

  // Prepare data for chart
  const chartData = ORGANS.map(org => ({
    organ: org,
    gap: currentInd.organGaps[org] || 0, // Fallback for safety
    age: currentInd.organAges[org] || currentInd.age // Fallback
  })).sort((a, b) => b.gap - a.gap); // Sort by gap descending for visualization

  // Logic for "Next Organ to Fail"
  const maxGapOrgan = chartData[0].gap > 0 ? chartData[0] : null;

  return (
    <div className="h-full flex flex-col animate-fadeIn">
      <SectionHeader title="Individual Explorer" subtitle="Examine Age Gaps and pseudo-trajectories for specific participants." />

      {/* Selector Bar */}
      <div className="bg-white border border-gray-300 rounded-sm shadow-sm p-4 mb-6 flex flex-wrap items-center gap-6">
         <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-full"><User size={20} /></div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase">Participant ID</label>
              <select 
                className="bg-transparent font-semibold text-slate-900 border-none focus:ring-0 p-0 cursor-pointer"
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
              >
                {individuals.map(i => <option key={i.id} value={i.id}>SEQN-{i.id}</option>)}
              </select>
            </div>
         </div>
         <div className="h-8 w-px bg-gray-200"></div>
         <div>
            <div className="text-xs text-gray-500 uppercase">Chronological Age</div>
            <div className="font-mono font-semibold text-slate-800">{currentInd.age} yrs</div>
         </div>
         <div className="h-8 w-px bg-gray-200"></div>
         <div>
            <div className="text-xs text-gray-500 uppercase">Sex</div>
            <div className="font-mono font-semibold text-slate-800">{currentInd.sex}</div>
         </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        
        {/* Main Chart: Age Gaps */}
        <div className="col-span-12 lg:col-span-7">
          <Card title="Biological Age Gap Profile" subtitle="Difference between Biological Age and Chronological Age per organ.">
             <div className="h-[400px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart
                      layout="vertical"
                      data={chartData}
                      margin={{ top: 20, right: 30, left: 40, bottom: 5 }}
                   >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" domain={['dataMin - 2', 'dataMax + 2']} hide />
                      <YAxis type="category" dataKey="organ" width={100} tick={{fontSize: 12}} />
                      <Tooltip 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-white p-3 border border-gray-200 shadow-lg rounded text-sm">
                                <p className="font-bold">{data.organ}</p>
                                <p className="text-gray-600">Bio Age: {data.age.toFixed(1)} yrs</p>
                                <p className={`${data.gap > 0 ? 'text-red-600' : 'text-green-600'} font-semibold`}>
                                  Gap: {data.gap > 0 ? '+' : ''}{data.gap.toFixed(1)} yrs
                                </p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <ReferenceLine x={0} stroke="#6B7280" strokeWidth={1.5} />
                      <Bar dataKey="gap" barSize={24}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.gap > 0 ? '#B91C1C' : '#047857'} fillOpacity={0.8} />
                        ))}
                      </Bar>
                   </BarChart>
                </ResponsiveContainer>
             </div>
             <div className="flex justify-center gap-8 mt-2 text-xs font-medium">
                <span className="flex items-center gap-2"><span className="w-3 h-3 bg-green-700 opacity-80"></span> Younger / Resilient</span>
                <span className="flex items-center gap-2"><span className="w-3 h-3 bg-red-700 opacity-80"></span> Older / Accelerated</span>
             </div>
          </Card>
        </div>

        {/* Right Panel: Insights */}
        <div className="col-span-12 lg:col-span-5 space-y-6">
           
           {/* Prediction Card */}
           <Card className="border-l-4 border-l-red-500">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-red-50 rounded-full text-red-600 mt-1">
                  <AlertTriangle size={24} />
                </div>
                <div>
                   <h3 className="text-lg font-bold text-gray-900">Vulnerability Projection</h3>
                   <p className="text-sm text-gray-500 mt-1 mb-4">Based on current cross-sectional deviation (AgeGap).</p>
                   
                   {maxGapOrgan ? (
                     <div className="space-y-3">
                       <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                          <span className="text-gray-600 text-sm">Primary Concern:</span>
                          <Badge color="red">{maxGapOrgan.organ}</Badge>
                       </div>
                       <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                          <span className="text-gray-600 text-sm">Acceleration:</span>
                          <span className="font-mono font-bold text-red-700">+{maxGapOrgan.gap.toFixed(1)} years</span>
                       </div>
                       <div className="flex justify-between items-center">
                          <span className="text-gray-600 text-sm">Confidence:</span>
                          <div className="flex gap-1">
                             <div className="w-8 h-2 bg-red-500 rounded-sm"></div>
                             <div className="w-8 h-2 bg-red-500 rounded-sm"></div>
                             <div className="w-8 h-2 bg-gray-200 rounded-sm"></div>
                          </div>
                       </div>
                       <p className="text-xs text-gray-500 italic mt-2">
                         "For participant {currentInd.id}, the {maxGapOrgan.organ} system shows the most advanced biological aging relative to chronological age."
                       </p>
                     </div>
                   ) : (
                     <div className="text-green-700 text-sm font-medium">
                       This individual shows resilient aging across all modeled systems.
                     </div>
                   )}
                </div>
              </div>
           </Card>

           {/* Trajectory Projection Box */}
           <Card title="Pseudo-Trajectory Forecast">
              <div className="relative pl-4 pb-2 pt-2 border-l-2 border-gray-200 space-y-6">
                 <div className="relative">
                    <div className="absolute -left-[21px] top-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white"></div>
                    <h4 className="text-sm font-bold text-gray-800">Current State ({currentInd.age}y)</h4>
                    <p className="text-xs text-gray-500">Bio Age Average: <span className="font-mono">{((Object.values(currentInd.organAges) as number[]).reduce((a, b) => a + b, 0) / 6).toFixed(1)}y</span></p>
                 </div>
                 <div className="relative">
                    <div className="absolute -left-[21px] top-1 w-3 h-3 bg-gray-300 rounded-full border-2 border-white"></div>
                    <h4 className="text-sm font-bold text-gray-500 flex items-center gap-2">Projection (+10y) <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 rounded text-gray-400">ESTIMATED</span></h4>
                    <div className="mt-2 text-xs text-gray-600 space-y-1">
                      {maxGapOrgan && (
                        <div className="flex justify-between">
                          <span>{maxGapOrgan.organ} trajectory:</span>
                          <span className="font-mono text-red-600">~{(currentInd.age + 10 + maxGapOrgan.gap * 1.2).toFixed(1)}y</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span>Systemic trajectory:</span>
                        <span className="font-mono">~{(currentInd.age + 10 + 1.5).toFixed(1)}y</span>
                      </div>
                    </div>
                 </div>
              </div>
              <div className="mt-4 p-2 bg-yellow-50 text-yellow-800 text-[10px] rounded border border-yellow-100">
                <strong>Note:</strong> Projections assume maintenance of current relative health percentile within the population cohort structure.
              </div>
           </Card>
        </div>
      </div>
    </div>
  );
};

export default IndividualExplorer;
