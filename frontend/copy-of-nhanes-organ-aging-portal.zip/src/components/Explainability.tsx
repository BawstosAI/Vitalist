
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, SectionHeader } from './Shared';
import { useData } from '../contexts/DataContext';

const Explainability: React.FC = () => {
  const { features } = useData();
  
  // Helper for chart data
  const dataLiver = (features['Liver'] || []).map(f => ({ name: f.name, val: f.importance, dir: f.direction }));
  const dataKidney = (features['Kidney'] || []).map(f => ({ name: f.name, val: f.importance, dir: f.direction }));

  return (
    <div className="h-full flex flex-col animate-fadeIn">
      <SectionHeader title="Explainability & Uncertainty" subtitle="Understanding model drivers (SHAP values) and confidence intervals." />

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 md:col-span-6">
          <Card title="Liver Clock: Top Features (SHAP Impact)">
             <div className="h-[300px] w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart layout="vertical" data={dataLiver} margin={{left: 40, right: 20}}>
                   <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                   <XAxis type="number" domain={[0, 0.5]} hide />
                   <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                   <Tooltip />
                   <Bar dataKey="val" barSize={20}>
                     {dataLiver.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={entry.dir === 'positive' ? '#EF4444' : '#3B82F6'} fillOpacity={0.7} />
                     ))}
                   </Bar>
                 </BarChart>
               </ResponsiveContainer>
             </div>
             <div className="px-4 pb-4 text-xs flex gap-4 justify-center text-gray-500">
               <div className="flex items-center gap-2"><div className="w-3 h-3 bg-red-500 opacity-70"></div> Positive Impact (Accelerates Aging)</div>
               <div className="flex items-center gap-2"><div className="w-3 h-3 bg-blue-500 opacity-70"></div> Negative Impact (Decelerates Aging)</div>
             </div>
          </Card>
        </div>

        <div className="col-span-12 md:col-span-6">
          <Card title="Kidney Clock: Top Features (SHAP Impact)">
             <div className="h-[300px] w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart layout="vertical" data={dataKidney} margin={{left: 40, right: 20}}>
                   <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                   <XAxis type="number" domain={[0, 0.5]} hide />
                   <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                   <Tooltip />
                   <Bar dataKey="val" barSize={20} fill="#EF4444" fillOpacity={0.7} />
                 </BarChart>
               </ResponsiveContainer>
             </div>
             <div className="px-4 pb-4 text-xs text-gray-500 text-center">
               All top features for Kidney model show positive correlation with age in this cohort.
             </div>
          </Card>
        </div>

        <div className="col-span-12">
          <Card title="Uncertainty Quantification">
             <div className="p-6 flex flex-col md:flex-row gap-8 items-center">
               <div className="flex-1 space-y-4 text-sm text-gray-600 leading-relaxed">
                 <p>
                   <strong className="text-gray-900 block mb-1">Why Uncertainty Matters?</strong>
                   Biological age is an estimation. The model's confidence varies based on the density of data points in NHANES. 
                   We observe higher uncertainty (wider confidence intervals) in:
                 </p>
                 <ul className="list-disc pl-5 space-y-1">
                   <li>Participants aged 80+ (Sparse data)</li>
                   <li>Participants with missing lab values (Imputation noise)</li>
                   <li>Outliers with extreme biomarker dysregulation</li>
                 </ul>
               </div>
               <div className="flex-1 bg-gray-50 border border-gray-200 p-4 rounded w-full">
                  <h4 className="font-semibold text-gray-800 mb-3 text-sm">Error Residuals vs Age</h4>
                  {/* Simple schematic CSS chart */}
                  <div className="relative h-32 w-full border-b border-l border-gray-300">
                    <div className="absolute bottom-0 left-0 w-full h-full flex items-end">
                       {/* Schematic bars representing error increasing with age */}
                       <div className="w-[10%] h-[10%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[12%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[15%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[18%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[25%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[35%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[50%] bg-blue-200 mx-[1%]"></div>
                       <div className="w-[10%] h-[70%] bg-blue-300 mx-[1%] border-t-2 border-red-400"></div>
                    </div>
                    <span className="absolute bottom-[-20px] right-0 text-xs text-gray-500">Age -></span>
                    <span className="absolute top-0 left-[-25px] text-xs text-gray-500 -rotate-90 origin-center">Error</span>
                  </div>
                  <p className="text-xs text-center mt-6 text-gray-500">Heteroscedasticity: Variance increases with age.</p>
               </div>
             </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Explainability;
