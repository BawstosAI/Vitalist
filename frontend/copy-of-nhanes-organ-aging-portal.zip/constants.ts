import { Biomarker, Individual, OrganMetric, ScatterPoint, TrajectoryPoint, OrganType } from './types';

export const ORGANS: OrganType[] = ['Liver', 'Kidney', 'Cardio-Metabolic', 'Immune', 'Lung', 'Musculoskeletal'];

// --- Mock Data Generation ---

// 1. Model Performance Metrics
export const ORGAN_PERFORMANCE: OrganMetric[] = [
  { organ: 'Liver', maeLinear: 6.4, maeNonLinear: 5.1, rmseLinear: 8.2, rmseNonLinear: 6.8, r2: 0.65 },
  { organ: 'Kidney', maeLinear: 5.8, maeNonLinear: 4.5, rmseLinear: 7.5, rmseNonLinear: 5.9, r2: 0.72 },
  { organ: 'Cardio-Metabolic', maeLinear: 4.2, maeNonLinear: 3.1, rmseLinear: 5.5, rmseNonLinear: 4.2, r2: 0.81 },
  { organ: 'Immune', maeLinear: 7.1, maeNonLinear: 6.2, rmseLinear: 9.1, rmseNonLinear: 7.8, r2: 0.55 },
  { organ: 'Lung', maeLinear: 5.5, maeNonLinear: 4.8, rmseLinear: 6.9, rmseNonLinear: 6.1, r2: 0.68 },
  { organ: 'Musculoskeletal', maeLinear: 6.0, maeNonLinear: 5.3, rmseLinear: 7.8, rmseNonLinear: 6.9, r2: 0.61 },
];

// 2. Feature Importance (Mock for Explainability)
export const LIVER_FEATURES: Biomarker[] = [
  { name: 'Albumin', category: 'Blood', importance: 0.28, direction: 'negative', description: 'Liver protein synthesis marker' },
  { name: 'GGT', category: 'Blood', importance: 0.22, direction: 'positive', description: 'Gamma-glutamyl transferase' },
  { name: 'ALP', category: 'Blood', importance: 0.15, direction: 'positive', description: 'Alkaline phosphatase' },
  { name: 'Total Bilirubin', category: 'Blood', importance: 0.12, direction: 'positive', description: 'Heme catabolism by-product' },
  { name: 'Alcohol Intake', category: 'Demographic', importance: 0.08, direction: 'positive', description: 'Self-reported consumption' },
];

export const KIDNEY_FEATURES: Biomarker[] = [
  { name: 'Creatinine', category: 'Urine', importance: 0.35, direction: 'positive', description: 'Kidney filtration marker' },
  { name: 'BUN', category: 'Blood', importance: 0.25, direction: 'positive', description: 'Blood Urea Nitrogen' },
  { name: 'Uric Acid', category: 'Blood', importance: 0.15, direction: 'positive', description: 'Waste product breakdown' },
  { name: 'Systolic BP', category: 'Physical', importance: 0.10, direction: 'positive', description: 'Blood Pressure' },
];

// 3. Scatter Plot Data (Simulating 200 points per organ)
export const generateScatterData = (organ: OrganType, type: 'Linear' | 'Non-Linear'): ScatterPoint[] => {
  const points: ScatterPoint[] = [];
  const perf = ORGAN_PERFORMANCE.find(p => p.organ === organ)!;
  const errorFactor = type === 'Linear' ? perf.maeLinear : perf.maeNonLinear;

  for (let i = 0; i < 300; i++) {
    const age = 18 + Math.random() * 62; // 18-80
    // Simulate non-linearity: older people have higher variance
    const variance = (age / 80) * errorFactor * 1.5; 
    const error = (Math.random() - 0.5) * 2 * variance;
    
    // Add a slight curve for "Non-Linear" simulation if linear model is used on non-linear data
    let bias = 0;
    if (type === 'Linear' && age > 65) bias = -3; // Linear underestimates old age often

    points.push({
      id: `P${i}`,
      chronoAge: age,
      bioAge: age + error + bias,
      organ,
      modelType: type,
    });
  }
  return points;
};

// 4. Individual Data (Mocking a few specific profiles)
export const INDIVIDUALS: Individual[] = [
  {
    id: '83721',
    age: 45,
    sex: 'Male',
    organAges: { 'Liver': 52.4, 'Kidney': 46.1, 'Cardio-Metabolic': 44.2, 'Immune': 43.8, 'Lung': 45.5, 'Musculoskeletal': 48.0 },
    organGaps: { 'Liver': 7.4, 'Kidney': 1.1, 'Cardio-Metabolic': -0.8, 'Immune': -1.2, 'Lung': 0.5, 'Musculoskeletal': 3.0 }
  },
  {
    id: '94022',
    age: 68,
    sex: 'Female',
    organAges: { 'Liver': 65.1, 'Kidney': 75.4, 'Cardio-Metabolic': 72.1, 'Immune': 67.0, 'Lung': 68.2, 'Musculoskeletal': 70.5 },
    organGaps: { 'Liver': -2.9, 'Kidney': 7.4, 'Cardio-Metabolic': 4.1, 'Immune': -1.0, 'Lung': 0.2, 'Musculoskeletal': 2.5 }
  },
  {
    id: '10234',
    age: 32,
    sex: 'Male',
    organAges: { 'Liver': 31.5, 'Kidney': 33.0, 'Cardio-Metabolic': 38.5, 'Immune': 30.2, 'Lung': 31.8, 'Musculoskeletal': 32.1 },
    organGaps: { 'Liver': -0.5, 'Kidney': 1.0, 'Cardio-Metabolic': 6.5, 'Immune': -1.8, 'Lung': -0.2, 'Musculoskeletal': 0.1 }
  }
];

// 5. Trajectories (Binned data)
export const generateTrajectories = (organ: OrganType): TrajectoryPoint[] => {
  const bins = ['18-30', '30-40', '40-50', '50-60', '60-70', '70-80'];
  
  // Different patterns for different organs
  let trend = 0;
  if (organ === 'Liver') trend = 0.2; // Slight increase
  if (organ === 'Cardio-Metabolic') trend = 0.8; // Acceleration
  if (organ === 'Immune') trend = 0.1; // Stable

  return bins.map((bin, idx) => {
    const meanGap = -1 + (idx * trend) + (Math.random() * 0.5);
    return {
      ageBin: bin,
      meanGap: meanGap,
      lowerCi: meanGap - 1.5,
      upperCi: meanGap + 1.5,
    };
  });
};
