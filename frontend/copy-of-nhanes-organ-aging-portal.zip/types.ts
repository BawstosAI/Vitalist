export type OrganType = 'Liver' | 'Kidney' | 'Cardio-Metabolic' | 'Immune' | 'Lung' | 'Musculoskeletal';

export interface OrganMetric {
  organ: OrganType;
  maeLinear: number;
  maeNonLinear: number;
  rmseLinear: number;
  rmseNonLinear: number;
  r2: number;
}

export interface Biomarker {
  name: string;
  category: 'Blood' | 'Urine' | 'Physical' | 'Demographic';
  importance: number; // 0-1
  direction: 'positive' | 'negative'; // correlates with aging
  description: string;
}

export interface Individual {
  id: string;
  age: number;
  sex: 'Male' | 'Female';
  organAges: Record<OrganType, number>; // Predicted Bio Ages
  organGaps: Record<OrganType, number>; // Bio - Chrono
}

export interface ScatterPoint {
  id: string;
  chronoAge: number;
  bioAge: number;
  organ: OrganType;
  modelType: 'Linear' | 'Non-Linear';
}

export interface TrajectoryPoint {
  ageBin: string;
  meanGap: number;
  lowerCi: number;
  upperCi: number;
}
